// This file is created by egg-ts-helper@1.30.2
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportWechat = require('../../../app/controller/wechat');

declare module 'egg' {
  interface IController {
    wechat: ExportWechat;
  }
}
